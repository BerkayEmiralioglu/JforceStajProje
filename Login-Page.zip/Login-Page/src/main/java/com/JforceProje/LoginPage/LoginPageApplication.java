package com.JforceProje.LoginPage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginPageApplication {

	public static void main(String[] args) throws SQLException {
		SpringApplication.run(LoginPageApplication.class, args);

		Connection connection =null;
		DbHelper helper =new DbHelper();
		try {

			connection = helper.getConnection();
			System.out.println("Bağlantı var");
		}
		catch (SQLException exception){
			helper.showErrorMessage(exception);

		}
		finally {
			connection.close();
		}
	}

}

