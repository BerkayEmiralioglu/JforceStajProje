package com.JforceProje.LoginPage;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
public class JavaFXController {

    @FXML
    private Button myButton;
}
