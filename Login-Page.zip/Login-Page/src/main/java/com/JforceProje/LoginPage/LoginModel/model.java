package com.JforceProje.LoginPage.LoginModel;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Table;

@Table
@Data
@Getter
@Setter

public class model {
}
