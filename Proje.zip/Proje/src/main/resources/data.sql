INSERT INTO "Position" (ID, VERSION, NAME) VALUES
(1, 1, 'Yazılım Geliştirme Uzmanı'),
(2, 1, 'Yönetmen Yardımcısı'),
(3, 1, 'Yönetmen');

INSERT INTO "Unit" (ID, VERSION, NAME) VALUES
(4, 1, 'Yazılım Geliştirme'),
(5, 1, 'Arge');

INSERT INTO contact (first_name, last_name, gender, birth_date, marital_status, tckn, sicil_numarasi,
 mezuniyet_durumu, çalışıyormu, employment_start_date, employment_end_date, employment_end_reason)
VALUES
 ('Mehmet', 'Aydın', 'M', '1992-04-05', 'Single', '34567890123', 103, 'Lisans', TRUE, '2018-09-20',
 NULL, NULL),
 ('Zeynep', 'Yıldız', 'F', '1987-11-18', 'Divorced', '45678901234', 104, 'Doktora', FALSE, '2010-07-01',
  '2023-04-30');


INSERT INTO inventory (inventory_type_id, inventory_entry_date, brand, model, serial_number,
status, inventory_received_date, inventory_return_date)
VALUES
 (1, '2021-02-15', 'BrandA', 'ModelB', 'SN54321', 'Active', '2021-02-15', NULL),
 (2, '2010-07-01', 'BrandC', 'ModelD', 'SN98765', 'Inactive', '2010-07-01', '2023-04-30');
