package com.example.application.data.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.vaadin.flow.component.charts.model.Title;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.*;

import java.time.LocalDate;

@Entity
public class Contact extends AbstractEntity {

    @NotEmpty
    private String firstName = "";


    @NotEmpty
    private String lastName = "";

    @ManyToOne
    @JoinColumn(name = "unit_id")
    @NotNull
    @JsonIgnoreProperties({"employees"})
    private Unit unit;

    @NotNull
    @ManyToOne
    private Position position;

    @NotEmpty
    private String gender;

    @NotNull
    private LocalDate birthDate;

    @NotEmpty
    @Size(min = 11, max = 11)
    @Column(unique = true)
    private String tckn;

    private boolean çalışıyormu;

    private LocalDate employmentStartDate;
    @ManyToOne
    private Position employmentStartPosisiton;
    @ManyToOne
    private Position employmentStartTitle;
    private LocalDate employmentEndDate;
    private String employmentEndReason;

    @ManyToOne
    private Inventoryİnformation inventoryİnformation;
    private LocalDate inventoryEntryDate;
    private String brand;
    private String model;
    private String serialNumber;
    private String status;


    @ManyToOne
    private Inventory inventory;
    private LocalDate inventoryReceivedDate;


    @ManyToOne
    private EmployeeInventory employeeInventory;
    private LocalDate inventoryReturnDate;
    @ManyToOne
    private EmployeeInventory receivedBy;



    public String getModel() {
        return model;
    }

    public String getStatus() {
        return status;
    }

    public EmployeeInventory getReceivedBy() {
        return receivedBy;
    }

    public void setReceivedBy(EmployeeInventory receivedBy) {
        this.receivedBy = receivedBy;
    }

    public LocalDate getInventoryReturnDate() {
        return inventoryReturnDate;
    }

    public void setInventoryReturnDate(LocalDate inventoryReturnDate) {
        this.inventoryReturnDate = inventoryReturnDate;
    }


    public LocalDate getInventoryReceivedDate() {
        return inventoryReceivedDate;
    }

    public void setInventoryReceivedDate(LocalDate inventoryReceivedDate) {
        this.inventoryReceivedDate = inventoryReceivedDate;
    }

    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public void setModel(String model) {
        this.model = model;
    }



    public LocalDate getBirthDate() {
        return birthDate;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public LocalDate getInventoryEntryDate() {
        return inventoryEntryDate;
    }

    public void setInventoryEntryDate(LocalDate inventoryEntryDate) {
        this.inventoryEntryDate = inventoryEntryDate;
    }

    public Inventoryİnformation getInventoryİnformation() {
        return inventoryİnformation;
    }

    public void setInventoryİnformation(Inventoryİnformation inventoryİnformation) {
        this.inventoryİnformation = inventoryİnformation;
    }

    public String getEmploymentEndReason() {
        return employmentEndReason;
    }

    public void setEmploymentEndReason(String employmentEndReason) {
        this.employmentEndReason = employmentEndReason;
    }

    public LocalDate getEmploymentEndDate() {
        return employmentEndDate;
    }

    public void setEmploymentEndDate(LocalDate employmentEndDate) {
        this.employmentEndDate = employmentEndDate;
    }

    public Position getEmploymentStartTitle() {
        return employmentStartTitle;
    }

    public void setEmploymentStartTitle(Position employmentStartTitle) {
        this.employmentStartTitle = employmentStartTitle;
    }

    public Position getEmploymentStartPosisiton() {
        return employmentStartPosisiton;
    }

    public void setEmploymentStartPosisiton(Position employmentStartPosisiton) {
        this.employmentStartPosisiton = employmentStartPosisiton;
    }

    public LocalDate getEmploymentStartDate() {
        return employmentStartDate;
    }

    public void setEmploymentStartDate(LocalDate employmentStartDate) {
        this.employmentStartDate = employmentStartDate;
    }

    public boolean isÇalışıyormu() {
        return çalışıyormu;
    }

    public void setÇalışıyormu(boolean çalışıyormu) {
        this.çalışıyormu = çalışıyormu;
    }

    public String getTckn() {
        return tckn;
    }

    public void setTckn(String tckn) {
        this.tckn = tckn;
    }

    public void setBirthDate(LocalDate birthDate) {
        this.birthDate = birthDate;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }



    @Override
    public String toString() {
        return firstName + " " + lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Unit getUnit() {
        return unit;
    }

    public void setUnit(Unit unit) {
        this.unit = unit;
    }

    public Position getPosition() {
        return position;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

}


