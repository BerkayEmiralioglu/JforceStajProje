package com.example.application.data.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.application.data.entity.Inventory;
import com.example.application.data.entity.Inventory;

public interface InventoryRepository extends JpaRepository<InventoryRepository, Long> {
}
