package com.example.application.data.repository;

import com.example.application.data.entity.Inventoryİnformation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InventoryİnformationRepository extends JpaRepository<Inventoryİnformation, Long> {
}
