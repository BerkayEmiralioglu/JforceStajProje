package com.example.application.data.repository;

import com.example.application.data.entity.EmployeeInventory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeInventoryRepository extends JpaRepository<EmployeeInventory, Long> {
}
