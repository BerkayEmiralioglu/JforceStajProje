package com.example.application.data.entity;

import jakarta.persistence.Entity;

@Entity
public class Position extends AbstractEntity {
    private String name;

    public Position() {

    }

    public Position(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
