package com.example.application.data.repository;

import com.example.application.data.entity.Unit;
import com.example.application.data.entity.Unit;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UnitRepository extends JpaRepository<Unit, Long> {

}
