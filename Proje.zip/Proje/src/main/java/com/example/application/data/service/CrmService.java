package com.example.application.data.service;

import com.example.application.data.entity.Unit;
import com.example.application.data.entity.Contact;
import com.example.application.data.entity.Position;
import com.example.application.data.repository.*;
import com.example.application.data.repository.PositionRepository;
import com.example.application.data.repository.UnitRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CrmService {

    private final ContactRepository contactRepository;
    private final UnitRepository unitRepository;
    private final PositionRepository positionRepository;

    private final InventoryİnformationRepository inventoryİnformationRepository;

    private final EmployeeInventoryRepository employeeInventoryRepository;

    private final InventoryRepository inventoryRepository;


    public CrmService(ContactRepository contactRepository,
                      UnitRepository unitRepository,
                      PositionRepository positionRepository, InventoryİnformationRepository inventoryİnformationRepository, EmployeeInventoryRepository employeeInventoryRepository, InventoryRepository inventoryRepository) {
        this.contactRepository = contactRepository;
        this.unitRepository = unitRepository;
        this.positionRepository = positionRepository;
        this.inventoryİnformationRepository = inventoryİnformationRepository;
        this.employeeInventoryRepository = employeeInventoryRepository;
        this.inventoryRepository = inventoryRepository;
    }

    public List<Contact> findAllContacts(String stringFilter) {
        if (stringFilter == null || stringFilter.isEmpty()) {
            return contactRepository.findAll();
        } else {
            return contactRepository.search(stringFilter);
        }
    }

    public long countContacts() {
        return contactRepository.count();
    }

    public void deleteContact(Contact contact) {
        contactRepository.delete(contact);
    }

    public void saveContact(Contact contact) {
        if (contact == null) {
            System.err.println("Contact is null. Are you sure you have connected your form to the application?");
            return;
        }
        contactRepository.save(contact);
    }

    public List<Unit> findAllUnits() {
        return unitRepository.findAll();
    }

    public List<Position> findAllPositions(){
        return positionRepository.findAll();
    }

}